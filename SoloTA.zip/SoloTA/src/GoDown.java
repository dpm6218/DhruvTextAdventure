public class GoDown extends Action{
    public GoDown(){ super(Method.GoDown, "Move Down", 's', null);}
}
public class GoLeft extends Action{
    public GoLeft(){ super(Method.GoLeft, "Go Left", 'a', null);}
}
public class Knife extends Weapon{
    public Knife(){
        super("Knife", "A dull kitchen knife, might come in handy later", 5, 10);
    }


}

public enum Method {
    Attack, ViewInventory, GoStraight, GoDown, GoLeft, GoRight
}

public class Key extends Item{
    public Key(){
        super("Key", "A shiny silver key, this could open a locked door!", 99);
    }
}

public class GoRight extends Action{
    public GoRight(){ super(Method.GoRight, "Go Right", 'd', null);}
}
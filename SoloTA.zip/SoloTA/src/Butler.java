public class Butler extends Enemy{
    public Butler(){
        super("Mysterious Butler", 10, 5);
    }
}

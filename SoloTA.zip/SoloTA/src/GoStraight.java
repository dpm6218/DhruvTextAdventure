public class GoStraight extends Action{
    public GoStraight(){ super(Method.GoStraight, "Go Straight", 'w', null);}
}

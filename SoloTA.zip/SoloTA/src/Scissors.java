public class Scissors extends Weapon{
    public Scissors(){
        super("Scissors", "Some scissors a kindergartener would use", 5, 5);
    }
}

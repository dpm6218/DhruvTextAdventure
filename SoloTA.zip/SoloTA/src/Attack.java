public class Attack extends Action {
    public Attack(){
        super(Method.Attack,"Attack", 'k', null);
    }
}

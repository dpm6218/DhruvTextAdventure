public class ViewInventory extends Action{
    public ViewInventory(){
        super(Method.ViewInventory,"View Inventory", 'i', null);
    }
}
